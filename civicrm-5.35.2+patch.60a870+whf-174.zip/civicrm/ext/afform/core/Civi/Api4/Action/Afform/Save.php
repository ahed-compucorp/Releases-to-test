<?php

namespace Civi\Api4\Action\Afform;

/**
 * @inheritDoc
 * @package Civi\Api4\Action\Afform
 */
class Save extends \Civi\Api4\Generic\BasicSaveAction {

  use \Civi\Api4\Utils\AfformSaveTrait;

}
