# org.civicrm.afform-mock

This is a dummy extension used for integration testing.

```
cd afform/mock
cv en afform_mock
phpunit5
```
