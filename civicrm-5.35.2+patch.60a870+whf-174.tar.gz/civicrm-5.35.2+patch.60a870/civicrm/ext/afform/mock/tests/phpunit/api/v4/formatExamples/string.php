<?php

return [
  'html' => 'hello world',
  'pretty' => 'hello world',
  'shallow' => [['#text' => 'hello world']],
  'deep' => [['#text' => 'hello world']],
];
