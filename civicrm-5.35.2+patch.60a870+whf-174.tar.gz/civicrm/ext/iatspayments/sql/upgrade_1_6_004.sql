DELETE FROM civicrm_job where api_action = 'iatsacheftverify'; 
