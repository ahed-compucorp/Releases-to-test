<?php
return [
  'entity' => 'Activity',
  'defaults' => "{'url-autofill': '1'}",
  'boilerplate' => [
    ['#tag' => 'af-field', 'name' => 'subject'],
  ],
];
