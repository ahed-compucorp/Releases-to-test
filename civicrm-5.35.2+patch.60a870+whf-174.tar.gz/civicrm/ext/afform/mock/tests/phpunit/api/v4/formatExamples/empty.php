<?php

return [
  'html' => '',
  'pretty' => '',
  'shallow' => [],
  'deep' => [],
];
