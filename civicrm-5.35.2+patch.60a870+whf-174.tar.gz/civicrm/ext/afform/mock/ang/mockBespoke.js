(function(angular, $, _) {
  // Declare a list of dependencies.
  angular.module('mockBespoke', CRM.angRequires('mockBespoke'));
})(angular, CRM.$, CRM._);
