<?php
// This file declares an Angular module which can be autoloaded
return [
  'js' => [
    'ang/afformStandalone.js',
  ],
  'css' => [],
  'settings' => [],
  'requires' => ['ngRoute'],
];
