# sequentialcreditnotes

Ensures a sequential credit note number is created whenever a contribution status is updated to refunded.
