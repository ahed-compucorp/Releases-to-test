<?php
namespace Civi\Crypto\Exception;

/**
 * Class CryptException
 */
class CryptoException extends \CRM_Core_Exception {

}
